﻿using System;

namespace ShoppingCartApp
{


	public class Products
	{
		public Products()
		{

		}
	}
}
