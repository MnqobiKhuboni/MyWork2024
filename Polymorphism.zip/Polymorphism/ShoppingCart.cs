﻿
using System;

namespace ShoppingCartApp
{

	public class ShoppingCart
	{
		public ShoppingCart()
		{

		}
	}
}
