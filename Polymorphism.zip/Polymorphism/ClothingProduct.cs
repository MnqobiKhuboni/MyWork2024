﻿using System;

namespace ShoppingCartApp
{


	public class ClothingProducts
	{
		public ClothingProducts()
		{
		}
	}
}
