﻿namespace Polymorphism
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Animal myAnimal = new Animal();  // Create a Animal object
            Animal myPig = new Pig();  // Create a Pig object
            Animal myDog = new Dog();  // Create a Dog object
            Animal myCat = new Cat(); //  Create a cat object 
            
            myAnimal.animalSound();
            myPig.animalSound();
            myDog.animalSound();
            myCat.animalSound();
        }
    }
}
