﻿using System;

namespace ShoppingCartApp
{


	public class ElectronicsProducts
	{
		public ElectronicsProducts()
		{
		}
	}
}
