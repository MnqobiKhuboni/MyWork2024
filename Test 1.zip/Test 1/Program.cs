﻿namespace Recipe_app
{
    class Recipe
    {
        public string[] ingredients;
        public int[] quantities;
        public string[] unitMeasurements;
        public string[] stepNames;
        public string[] stepDescriptions;
        public int scaleAmount;

        public void Ingredients()
        {
            Console.WriteLine("Please enter the number of ingredients:");
            int numberOfIngredients;
            if (!int.TryParse(Console.ReadLine(), out numberOfIngredients) || numberOfIngredients <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
                return;
            }

            ingredients = new string[numberOfIngredients];
            quantities = new int[numberOfIngredients];
            unitMeasurements = new string[numberOfIngredients];
            for (int i = 0; i < numberOfIngredients; i++)
            {
                Console.WriteLine($"Ingredient {i + 1}:");
                ingredients[i] = Console.ReadLine();

                Console.WriteLine($"Quantity of {ingredients[i]}:");
                quantities[i] = int.Parse(Console.ReadLine());

                Console.WriteLine($"Unit of measurement for {ingredients[i]}:");
                unitMeasurements[i] = Console.ReadLine();
            }
        }

        public void NumberOfSteps()
        {
            Console.WriteLine("Please enter the number of steps:");
            int numberOfSteps;
            if (!int.TryParse(Console.ReadLine(), out numberOfSteps) || numberOfSteps <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
                return;
            }
            stepNames = new string[numberOfSteps];
            stepDescriptions = new string[numberOfSteps];

            for (int i = 0; i < numberOfSteps; i++)
            {
                Console.WriteLine($"Step {i + 1}:");
                stepNames[i] = Console.ReadLine();

                Console.WriteLine($"Description for step {i + 1}:");
                stepDescriptions[i] = Console.ReadLine();
            }
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            for (int i = 0; i < ingredients.Length; i++)
            {
                Console.WriteLine($"Ingredient: {ingredients[i]}, Quantity: {quantities[i]}, Unit: {unitMeasurements[i]}");
            }

            Console.WriteLine("Steps:");
            if (stepNames == null || stepNames.Length == 0)
            {
                Console.WriteLine("No steps available");
            }
            else
            {
                for (int i = 0; i < stepNames.Length; i++)
                {
                    Console.WriteLine($"Step {i + 1}: {stepNames[i]} - {stepDescriptions[i]}");
                }
            }
        }

        public void ScaleRecipe()
        {
            Console.WriteLine("Please enter the scaling amount:");
            int scalingFactor = int.Parse(Console.ReadLine());

            // Scale quantities
            for (int i = 0; i < quantities.Length; i++)
            {
                quantities[i] *= scalingFactor;
            }
        }

        public void ResetQuantities()
        {
            Console.WriteLine("Are you sure you want to reset quantities? (yes/no)");
            string answer = Console.ReadLine();
            if (answer.ToLower() == "yes")
            {
                Array.Clear(quantities, 0, quantities.Length);
                scaleAmount = 0;
            }
        }

        public void ClearData()
        {
            Console.WriteLine("Are you sure you want to clear all data? (yes/no)");
            string answer = Console.ReadLine();
            if (answer.ToLower() == "yes")
            {
                Array.Clear(ingredients, 0, ingredients.Length);
                Array.Clear(quantities, 0, quantities.Length);
                Array.Clear(unitMeasurements, 0, unitMeasurements.Length);
                Array.Clear(stepNames, 0, stepNames.Length);
                Array.Clear(stepDescriptions, 0, stepDescriptions.Length);
                scaleAmount = 0;
            }
        }
    }
    class RecipeApp
    {
        static void Main(string[] args)
        {
            int option;
            Recipe recipe = new Recipe();

            do
            {
                Console.WriteLine("\nWelcome to the Recipe App!\n" +
                                    "Please choose an option:\n" +
                                    "1. Enter Recipe ingredients\n" +
                                    "2. Enter Recipe steps\n" +
                                    "3. Display the full recipe\n" +
                                    "4. Scale recipe\n" +
                                    "5. Reset quantities\n" +
                                    "6. Clear all data\n" +
                                    "7. Exit");

                option = int.Parse(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        recipe.Ingredients();
                        break;
                    case 2:
                        recipe.NumberOfSteps();
                        break;
                    case 3:
                        recipe.DisplayRecipe();
                        break;
                    case 4:
                        recipe.ScaleRecipe();
                        break;
                    case 5:
                        recipe.ResetQuantities();
                        break;
                    case 6:
                        recipe.ClearData();
                        break;
                    case 7:
                        Console.WriteLine("Exiting the application. Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please choose a number between 1 and 7.");
                        break;
                }
            } while (option != 7);
        }
    }
}
